package com.sergeyorshanskiy.domain

class DataPoint {

    static constraints = {
    }
}
